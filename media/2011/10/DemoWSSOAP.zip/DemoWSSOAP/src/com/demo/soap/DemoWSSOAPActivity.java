package com.demo.soap;

import java.io.IOException;
import java.util.Vector;
import org.apache.http.client.HttpClient;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;



import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class DemoWSSOAPActivity extends Activity {
	
	
	private static final String SOAP_ACTION = "http://ws.cdyne.com/CCServerCheck";
	private static final String METHOD_NAME = "CCServerCheck";
	private static final String NAMESPACE = "http://ws.cdyne.com/";
	private static final String URL = "http://ws.cdyne.com/psaddress/addresslookup.asmx";
	private String resultadoFINAL;    
	
	
	
	
	
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
        TextView lblStatus = (TextView) findViewById(R.id.lblStatus);
        try {
	       //Creaccion de la Solicitud
			SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
			//Creaccion del Envelope
			SoapSerializationEnvelope sobre = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			sobre.dotNet = true;
			sobre.setOutputSoapObject(request);
			//Creaccion del transporte
			HttpTransportSE transporte = new HttpTransportSE(URL);
			//Llamada
			transporte.call(SOAP_ACTION, sobre);
			//Resultado
			SoapPrimitive resultado = (SoapPrimitive) sobre.getResponse();
			resultadoFINAL = resultado.toString();
			lblStatus.setText("Resultado:" + resultadoFINAL); 
        }catch (Exception e) {
        	lblStatus.setText("ERROR:" + e.getClass().getName() + ": " + e.getMessage()); 
        }

    }
}